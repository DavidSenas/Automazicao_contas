
           var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "na.s3l1wmrc.lunaproxy.net",
                port: parseInt(12233)
              },
              bypassList: ["localhost"]
            }
           };

           chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

           function callbackFn(details) {
            return {
              authCredentials: {
                username: "user-tunnelbroker-region-us",
                password: "1lw2S9WxUwFFT28"
              }
            };
           }

           chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
           );
           